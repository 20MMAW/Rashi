// Vercel serverless function: POST /api/chat
// Body: { messages: [{role, content}], hebrew: boolean }
// Returns: { text }

const MODEL = "claude-sonnet-5-5";
const MAX_TOOL_ROUNDS = 4;

const SYSTEM = `You are Rashi, a Torah study companion built around the Sefaria library (sefaria.org). You help people explore Tanakh, Talmud, Mishnah, Midrash, Halakhah, Chasidut, and Jewish thought.

Sourcing
- Before quoting any text, call the get_text tool with a Sefaria reference (e.g. "Genesis 1:1", "Berakhot 2a:1", "Rashi on Genesis 1:1") and quote only what it returns.
- If you are unsure of an exact reference, use search_sefaria to find it. Never invent a citation or quote.
- Cite every source in Sefaria style. Name the English translation when the tool provides it.
- Separate clearly what the text says, what a commentator says, and your own explanation.

Teaching style
- Start with the plain meaning, then offer deeper layers (midrash, law, philosophy, mysticism) if asked.
- Present multiple views fairly, naming who said what and roughly when.
- Act as a study partner (chavruta), not an authority.
- Assume no prior knowledge; explain technical terms briefly the first time.
- End with a related text or a next step.

Boundaries
- For practical halakhic questions, lay out sources and opinions, then recommend asking a qualified rabbi.
- Respect all Jewish denominations and approaches.
- Keep answers under about 200 words unless asked to go deeper. Plain text, no markdown headers.`;

const LANG_EN = "\n\nLanguage: respond only in English. Quote English translation only; never include Hebrew or Aramaic script.";
const LANG_HE = "\n\nLanguage: respond in English, but when quoting a text, give the original Hebrew/Aramaic first on its own line, then the English translation.";

const TOOLS = [
  {
    name: "get_text",
    description: "Fetch the text of a passage from Sefaria by reference, in English and Hebrew. Use Sefaria reference style, e.g. 'Genesis 1:1', 'Pirkei Avot 1:14', 'Berakhot 2a', 'Rashi on Genesis 1:1'.",
    input_schema: {
      type: "object",
      properties: { ref: { type: "string", description: "Sefaria reference" } },
      required: ["ref"],
    },
  },
  {
    name: "search_sefaria",
    description: "Search the Sefaria library for passages matching a phrase or topic. Returns references to then fetch with get_text.",
    input_schema: {
      type: "object",
      properties: { query: { type: "string" } },
      required: ["query"],
    },
  },
];

// ---------- Sefaria helpers ----------
const clean = (s) => String(s).replace(/<[^>]*>/g, "").replace(/&[a-z]+;/g, " ").replace(/\s+/g, " ").trim();
const flat = (t) => (Array.isArray(t) ? t.flat(Infinity).map(clean).filter(Boolean).join(" ") : clean(t || ""));

async function getText(ref) {
  const url = `https://www.sefaria.org/api/v3/texts/${encodeURIComponent(ref)}?version=english&version=hebrew`;
  const r = await fetch(url);
  if (!r.ok) return { error: `Sefaria could not find "${ref}" (status ${r.status}).` };
  const d = await r.json();
  const out = { ref: d.ref || ref, english: null, hebrew: null };
  for (const v of d.versions || []) {
    const key = v.language === "he" ? "hebrew" : "english";
    if (out[key]) continue;
    out[key] = { translation: v.versionTitle, text: flat(v.text).slice(0, 5000) };
  }
  return out;
}

async function searchSefaria(query) {
  const r = await fetch("https://www.sefaria.org/api/search-wrapper", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ query, type: "text", size: 6 }),
  });
  if (!r.ok) return { error: `Search failed (status ${r.status}).` };
  const d = await r.json();
  const hits = (d.hits && d.hits.hits) || [];
  return hits.slice(0, 6).map((h) => ({
    ref: h._source && h._source.ref,
    snippet: clean(((h.highlight && Object.values(h.highlight)[0]) || [""])[0]).slice(0, 300),
  }));
}

async function runTool(name, input) {
  try {
    if (name === "get_text") return await getText(input.ref);
    if (name === "search_sefaria") return await searchSefaria(input.query);
    return { error: "Unknown tool" };
  } catch (e) {
    return { error: "Tool failed: " + e.message };
  }
}

// ---------- Anthropic call ----------
async function callClaude(system, messages) {
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({ model: MODEL, max_tokens: 1200, system, tools: TOOLS, messages }),
  });
  if (!r.ok) throw new Error(`Anthropic API error ${r.status}: ${await r.text()}`);
  return r.json();
}

// ---------- Basic per-IP rate limit (best effort; use Upstash/Vercel KV for production) ----------
const hits = new Map();
function limited(ip) {
  const now = Date.now(), win = 60_000, max = 12;
  const arr = (hits.get(ip) || []).filter((t) => now - t < win);
  arr.push(now);
  hits.set(ip, arr);
  return arr.length > max;
}

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });
  const ip = (req.headers["x-forwarded-for"] || "").split(",")[0] || "unknown";
  if (limited(ip)) return res.status(429).json({ error: "rate_limited" });

  try {
    const { messages = [], hebrew = false } = req.body || {};
    const history = messages
      .filter((m) => (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
      .slice(-12)
      .map((m) => ({ role: m.role, content: m.content.slice(0, 4000) }));
    if (!history.length || history[history.length - 1].role !== "user") {
      return res.status(400).json({ error: "bad_request" });
    }

    const system = SYSTEM + (hebrew ? LANG_HE : LANG_EN);
    const convo = [...history];
    let reply;

    for (let i = 0; i < MAX_TOOL_ROUNDS; i++) {
      reply = await callClaude(system, convo);
      if (reply.stop_reason !== "tool_use") break;
      convo.push({ role: "assistant", content: reply.content });
      const results = [];
      for (const block of reply.content) {
        if (block.type === "tool_use") {
          const out = await runTool(block.name, block.input);
          results.push({ type: "tool_result", tool_use_id: block.id, content: JSON.stringify(out) });
        }
      }
      convo.push({ role: "user", content: results });
    }

    const text = (reply.content || []).filter((b) => b.type === "text").map((b) => b.text).join("\n").trim();
    return res.status(200).json({ text: text || "I couldn’t find an answer. Could you rephrase?" });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: "server_error" });
  }
}
