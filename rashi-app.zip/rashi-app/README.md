# Rashi: Torah study companion (Sefaria-powered)

A chat app where Claude answers using real text fetched from Sefaria.

## Structure
- `public/index.html`  the chat UI (installable as a PWA)
- `api/chat.js`        serverless backend: holds your API key, calls Claude, lets Claude fetch texts from Sefaria
- `.env.example`       the environment variable you need

## Deploy on Vercel (about 10 minutes)
1. Get an API key at https://console.anthropic.com and set a monthly spend limit.
2. Put this folder in a GitHub repo (or run `npm i -g vercel` then `vercel` inside the folder).
3. In Vercel: New Project, import the repo.
4. Project Settings, Environment Variables: add `ANTHROPIC_API_KEY`.
5. Deploy. Open the URL on your phone and choose "Add to Home Screen".

## Run locally
    npm i -g vercel
    cp .env.example .env     # add your real key
    vercel dev

## Before you launch publicly
- Replace the in-memory rate limiter in `api/chat.js` with Vercel KV or Upstash Redis (serverless instances don't share memory).
- Add login or a daily cap per user so costs stay predictable.
- Add icons to `manifest.json` (192px and 512px PNGs).
- Credit Sefaria and the translation sources in the footer (check sefaria.org terms).
- To ship to the App Store / Google Play, wrap the same backend with Expo (React Native) or Capacitor.

## Notes
- The Sefaria search response parsing in `searchSefaria` is written defensively but not tested against the live API. Try it and adjust if results look empty.
- Model name is set at the top of `api/chat.js`.
